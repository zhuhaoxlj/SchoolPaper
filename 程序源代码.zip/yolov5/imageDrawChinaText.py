import cv2
import PIL
from PIL import Image, ImageFont, ImageDraw
import numpy as np


def show_chinese(img, text, pos):
    """
    :param img: opencv 图片
    :param text: 显示的中文字体
    :param pos: 显示位置
    :return:    带有字体的显示图片（包含中文）
    """
    img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    font = ImageFont.truetype(font='msyh.ttc', size=36)
    draw = ImageDraw.Draw(img_pil)
    draw.text(pos, text, font=font, fill=(0, 0, 0))  # PIL中RGB=(255,0,0)表示红色
    img_cv = np.array(img_pil)  # PIL图片转换为numpy
    img = cv2.cvtColor(img_cv, cv2.COLOR_RGB2BGR)  # PIL格式转换为OpenCV的BGR格式
    return img


if __name__ == "__main__":
    txtContent = ['000', '01', '01', '624 810', '1318 810', '-77 1080', '1967 1080']
    image = cv2.imread("result.png")
    # for index, value in enumerate(txtContent):
    #     print(index, value)
    #     image = show_chinese(img=image, text=value, pos=(1, 60 * index))
    # 第一行 左直右
    # 第二行
    # 第三行
    direction = '未检测到转向标志'
    if txtContent[0] == '100':
        direction = '左转'
    elif txtContent[0] == '001':
        direction = '右转'
    elif txtContent[0] == '010':
        direction = '直行'
    elif txtContent[0] == '110':
        direction = '直行或左转'
    elif txtContent[0] == '011':
        direction = '直行或右转'
    elif txtContent[0] == '101':
        direction = '左转或右转'

    pts = np.array(
        [txtContent[3].strip().split(' '), txtContent[4].strip().split(' '), txtContent[6].strip().split(' '),
         txtContent[5].strip().split(' ')], np.int32)
    # image = show_chinese(img=image, text=direction, pos=(1, 1))
    # image = cv2.circle(image, (1318, 810), 10, (253, 205, 26), 20)
    zeros = np.zeros(image.shape, dtype=np.uint8)
    # mask = cv2.fillConvexPoly(zeros, pts, color=(0, 80, 0))
    mask = cv2.fillPoly(zeros, [pts], color=(0, 165, 255))
    mask_img = image + 0.3 * mask
    # mask_img = np.uint8(mask_img)
    print(mask_img.shape)
    cv2.imwrite("hhhh.png", mask_img)
    # 这里一定要除以 256
    cv2.imshow("result", cv2.resize(mask_img , (960, 540)))
    cv2.waitKey(0)
