import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from PIL import Image

def calculate_slope(line):
  """ 计算线段的斜率k

  Args:
      line (list): 两个点的x,y坐标(二维数组)

  Returns:
      double: 直线的k值
  """
  x_1, y_1, x_2, y_2 = line[0]
  return (y_2 - y_1) / (x_2 - x_1)

def get_line_k(pointList):
  """ 计算线段的斜率k

  Args:
      line (list): 两个点的x,y坐标,一维数组

  Returns:
      double: 直线的k值
  """
  x_1, y_1, x_2, y_2 = pointList[0],pointList[1],pointList[2],pointList[3]
  return (y_2 - y_1) / (x_2 - x_1)

def drawWholeLine(img,pointList):
  newPointList = []
  k = get_line_k(pointList)
  b = get_line_b(pointList[0],pointList[1],k)
  p1x = get_x_pos(0,k,b)
  newPointList.append(int(p1x))
  newPointList.append(0)
  if k < 0:
    newPointList.append(0)
    p2y = get_y_pos(0,k,b)
    newPointList.append(int(p2y))
  else:
    newPointList.append(1920)
    p2y = get_y_pos(1920,k,b)
    newPointList.append(int(p2y))
  cv2.line(img,(newPointList[0],newPointList[1]),(newPointList[2],newPointList[3]),(0,0,255),4)

  return img

def get_line_b(x,y,k):
  return y - k * x

def get_x_pos(y,k,b):
  return  (y - b)/k

def get_y_pos(x,k,b):
  return k * x + b

def least_squares_fit(lines):
    """
    将lines中的线段拟合成一条线段
    :param lines: 线段集合, [np.array([[x_1, y_1, x_2, y_2]]),np.array([[x_1, y_1, x_2, y_2]]),...,np.array([[x_1, y_1, x_2, y_2]])]
    :return: 线段上的两点,np.array([[xmin, ymin], [xmax, ymax]])
    """
    # 1. 取出所有坐标点
    x_coords = np.ravel([[line[0][0], line[0][2]] for line in lines])
    y_coords = np.ravel([[line[0][1], line[0][3]] for line in lines])
    # 2. 进行直线拟合.得到多项式系数
    poly = np.polyfit(x_coords, y_coords, deg=1)
    # 3. 根据多项式系数,计算两个直线上的点,用于唯一确定这条直线
    point_min = (np.min(x_coords), np.polyval(poly, np.min(x_coords)))
    point_max = (np.max(x_coords), np.polyval(poly, np.max(x_coords)))
    return np.array([point_min, point_max], dtype=np.int64)
