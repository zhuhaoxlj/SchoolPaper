import os
from os import path
from warnings import WarningMessage 

def scanFile (filePath,isShowDetails):
  """扫描当前文件夹下所有文件

  Args:
      filePath (str): 文件夹路径
  Returns:
      list: 文件路径
  """
  #遍历当前路径下所有文件
  file  = os.listdir(filePath)
  fileList = []
  for f in file:
      #字符串拼接
      real_url = path.join (filePath , f)
      fileList.append(real_url)
      #打印出来
      if isShowDetails:
        print("scan file --> " + real_url)
  print("共扫描到"+str(len(fileList))+"个文件")
  return fileList

def readSingleLineFromEachFile(filePathList,lineIndex):
  """读取所有txt文件指定行内容并返回list

  Args:
      filePathList (list): txt文件路径列表
      lineIndex (int): 读取txt中第几行

  Returns:
      list: 返回所有txt文件中第lineIndex行内容的列表
  """
  objectLineList = []
  for i in filePathList:
    if len(readDataFromText(i,False)) == 7:
      objectLineList.append(readDataFromText(i,False)[lineIndex-1])
  return objectLineList

def fixYoloWrongValue(txtFilePath,fixLineIndex):
  txtFileList = scanFile(txtFilePath,False)
  for index,filePath in enumerate(txtFileList):
    currentLineValue = readDataFromText(filePath,False)[fixLineIndex-1]
    if index - 1 >= 0:
      preLineIndex = index - 1
    else:
      preLineIndex = index
    preLineValue = readDataFromText(txtFileList[preLineIndex],False)[fixLineIndex-1]
    if index + 1 < len(txtFileList):
      nextLineIndex = index + 1
    else:
      nextLineIndex
    nextLineValue = readDataFromText(txtFileList[nextLineIndex],False)[fixLineIndex-1]
    
    if currentLineValue != preLineValue and currentLineValue != nextLineValue and nextLineValue == preLineValue:
      # 写数据
      fixedLineValue = readDataFromText(filePath,False)[fixLineIndex] = preLineValue
      writeDataToText(filePath,fixedLineValue)

def readDataFromText(filePath,isShowNewLine):
  """    从txt文件中读取数据到list

  Args:
      filePath (str): 文件路径
      isShowNewLine (bool): 获取到的list是否包含行尾的换行符

  Returns:
      list: txt每行的内容作为list返回
  """
  f = open(filePath,'r',encoding='utf-8') 
  line = f.readline()
  lines = []
  while line:
    if isShowNewLine:
      lines.append(line)
    else:
      lines.append(line.replace("\n",""))
    line = f.readline()
  f.close()
  return lines
  
def writeDataToText(filePath,contentList):
  """把contentList每个元素作为一行内容写入txt文件

  Args:
      filePath (str): txt文件路径
      contentList (list): 待写入内容的list
  """  
  parentPath = filePath
  pathContainPart = filePath.split("/")
  if len(pathContainPart) > 1:
    parentPath = filePath.split("/")[-2]
  if not os.path.exists(parentPath):
    print(parentPath+"文件夹不存在，已自动创建")
    os.makedirs(parentPath)
  print(filePath)
  f = open(filePath, 'w', encoding='utf-8')
  n = len(contentList)
  for index,value in enumerate(contentList):
      if index+1 != n:
        f.writelines(str(value)+'\n')
      else:
        f.writelines(str(value))
  f.close()
  

def checkTextFile(filePath):
  warningList = []
  contentList = readDataFromText(filePath,False)
  if len(contentList) != 7:
    print("!!! txt 文件行数异常 !!!")

def checkTextFile(checkFileList,isShowDetails):
  warningList = []
  warningMessage = ""
  for filePath in checkFileList:
    contentList = readDataFromText(filePath,False)
    lines = len(contentList)
    # 检查行数
    if lines != 7:
      # todo print format
      warningMessage = warningMessage + "文件:"+filePath+" --> 行数异常! lines = "+str(lines)
    else:
      warningMessage = warningMessage + "文件:"+filePath
      # 检查第一行数据
      lineOneText = contentList[0]
      if len(lineOneText) !=3:
        warningMessage = warningMessage + " ==> 第1行数据异常! strLength = "+str(len(lineOneText))
      # 检查第二行数据
      lineTwoText = contentList[1]
      if len(lineTwoText) !=2:
        warningMessage = warningMessage + " ==> 第2行数据异常! strLength = "+str(len(lineTwoText))
      # 检查第三行数据
      lineThreeText = contentList[2]
      if len(lineThreeText) !=2:
        warningMessage = warningMessage + " ==> 第3行数据异常! strLength = "+str(len(lineThreeText))
      # 检查第四行数据
      lineFourText = contentList[3]
      lineFourParts = lineFourText.split(" ")
      if len(lineFourParts) !=2:
        warningMessage = warningMessage + " ==> 第4行数据异常! data = "+lineFourText
      y = lineFourText[-3:]
      if y != "810":
        warningMessage = warningMessage + " ==> 第4行数据异常! y = "+y
      # 检查第五行数据
      lineFiveText = contentList[4]
      lineFiveParts = lineFiveText.split(" ")
      if len(lineFiveParts) !=2:
        warningMessage = warningMessage + " ==> 第5行数据异常! data = "+lineFiveText
      y = lineFiveText[-3:]
      if y != "810":
        warningMessage = warningMessage + " ==> 第5行数据异常! y = "+y
      # 检查第六行数据
      lineSixText = contentList[5]
      lineSixParts = lineSixText.split(" ")
      if len(lineSixParts) !=2:
        warningMessage = warningMessage + " ==> 第6行数据异常! data = "+lineSixText
      y = lineSixText[-4:]
      if y != "1080":
        warningMessage = warningMessage + " ==> 第6行数据异常! y = "+y
      # 检查第七行数据
      lineSevenText = contentList[6]
      lineSevenParts = lineSevenText.split(" ")
      if len(lineSevenParts) !=2:
        warningMessage = warningMessage + " ==> 第7行数据异常! data = "+lineSevenText
      y = lineSevenText[-4:]
      if y != "1080":
        warningMessage = warningMessage + " ==> 第7行数据异常! y = "+y
    if isShowDetails:
      print(warningMessage)
    warningList.append(warningMessage)
    warningMessage = ""
  writeDataToText("./checkFileResult.log",warningList)
  print("文件校验完成，校验结果请查看文件:\n"+"./checkFileResult.log") 

