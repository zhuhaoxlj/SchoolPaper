import txtUtils

txtFileList = txtUtils.scanFile("result",False)
txtUtils.checkTextFile(txtFileList,False)